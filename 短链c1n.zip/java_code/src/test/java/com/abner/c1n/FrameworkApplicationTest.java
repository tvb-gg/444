package com.abner.c1n;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * 
 * @author 01383518
 * @date:   2019年6月13日 下午3:10:22
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class FrameworkApplicationTest {

	@Test
	public void contextLoads() {
	}

}
